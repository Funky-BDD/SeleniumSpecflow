﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace $safeprojectname$
{
    public class ContentHub
    {

        [FindsBy(How = How.ClassName, Using = "mod-content-hub-overview__title-enchanted")]
        [CacheLookup]
        private IWebElement _contentHubTitle;

        public ContentHub()
        {
            PageFactory.InitElements(Hooks.Driver, this);
        }

        public string title => _contentHubTitle.Text;

    }
}
