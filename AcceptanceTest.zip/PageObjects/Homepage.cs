using System.Collections.Generic;
using System.Linq;
using System.Threading;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace $safeprojectname$
{
    public class HomePage
    {
        private class _teaserButton
        {
            public IWebElement element { get; set; }
            public string label { get; set; }
            public string target { get; set; }
        }

        private static Dictionary<string, IWebElement> _langSelector = new Dictionary<string, IWebElement>();
        private static IEnumerable<_teaserButton> _navigationTeasers;

        [FindsBy(How = How.TagName, Using = "body")]
        [CacheLookup]
        private IWebElement _homepage;

        [FindsBy(How = How.ClassName, Using = "intro__title")]
        [CacheLookup]
        private IWebElement _homepageTitle;

        private void _initElements()
        {
            PageFactory.InitElements(Hooks.Driver, this);
            _langSelector["de"] = Hooks.Driver.FindElement(By.CssSelector(".hidden-xs a[hreflang='de']"));
            _langSelector["en"] = Hooks.Driver.FindElement(By.CssSelector(".hidden-xs a[hreflang='en']"));
            _navigationTeasers = from contract in Hooks.Driver.FindElements(By.ClassName("mod-teaser-home"))
                                 select new _teaserButton
                                 {
                                     element = contract.FindElement(By.TagName("a")),
                                     label = contract.FindElement(By.TagName("h3")).Text,
                                     target = ""
                                 };
        }

        public HomePage()
        {
            // Hide disclaimer overlay when exists
            try
            {
                Hooks.Driver.LocalStorageSetItem("swisslife.web.disclaimer", "1");
                Hooks.Driver.ExecuteScript("document.getElementsByClassName('layout__overlay')[0].style.display='none'");
                Hooks.Driver.ExecuteScript("document.getElementsByClassName('layout__disclaimer')[0].style.display='none'");
            }
            catch (System.Exception e)
            {
                // Ignore Javascript errors
            }
            _initElements();
        }


        public void ScrollDown()
        {
            Hooks.Driver.FindElement(By.TagName("body")).SendKeys(Keys.PageDown);
        }

        public string HomepageTitle => _homepageTitle.Text;

        public bool IsSideBarVisible => Hooks.Driver.IsElementPresent(By.CssSelector(".mod.mod-social-sidebar.state-visible"));

        public void ChangeLang(string lang)
        {
            _langSelector[lang].Click();
            Thread.Sleep(2000);
            _initElements();
        }

        public string IsTeaserAvailable(string TeaserLabel) => (from e in _navigationTeasers
                                                                where e.label.Equals(TeaserLabel)
                                                                select e.label).SingleOrDefault();
    }
}
