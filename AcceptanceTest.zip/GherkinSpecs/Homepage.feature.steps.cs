﻿using TechTalk.SpecFlow;
using Xunit;

namespace $safeprojectname$
{
    [Binding]
    public sealed class Homepage
    {
        private static HomePage _homepage;
        private static ContentHub _contentHub;


        [Given(@"I open the Swiss Life Homepage")]
        public void GivenIOpenTheSwissLifeHomepage()
        {
            Hooks.Driver.Navigate().GoToUrl("https://www.swisslife.com/");
            _homepage = new HomePage();
        }

        [When(@"I go to the Info Hub")]
        public void WhenIGoToTheInfoHub()
        {
            Hooks.Driver.NavigateToPath("/de/hub.html");
        }

        [Then(@"I see the Info Hub Page")]
        public void ISeeTheInfoHubPage()
        {
            _contentHub = new ContentHub();
        }

        [Then(@"The title contains Content Hub")]
        public void ThenTheTitleContainsContentHub()
        {
            Assert.Contains("Content Hub", _contentHub.title);
        }

        [When(@"I change the language to (.*)")]
        public void WhenIChangeTheLanguageToDe(string lang)
        {
            _homepage.ChangeLang(lang);
        }

        [Then(@"The Homepage has the right (.*)")]
        public void ThenTheHomepageHasTheRightWillkommenBeiDerSwissLife_Gruppe(string title)
        {
            Assert.Equal(title, _homepage.HomepageTitle);
        }

        [When(@"I scroll down")]
        public void WhenIScrollDown()
        {
            _homepage.ScrollDown();
        }

        [Then(@"I see the Side Bar")]
        public void ThenISeeTheSideBar()
        {
            Assert.True(_homepage.IsSideBarVisible);
        }

        [Then(@"Teaser (.*) is present")]
        public void ThenTeaserDieSwissLifeGruppeIsPresent(string label)
        {
            Assert.Equal(label, _homepage.IsTeaserAvailable(label));
        }

    }
}
