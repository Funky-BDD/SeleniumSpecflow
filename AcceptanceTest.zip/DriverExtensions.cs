﻿using System;
using System.Drawing;
using System.IO;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace $safeprojectname$
{
    public static class DriverExtensions
    {
        #region NavigateToPath
        /// <summary>
        ///     Navigiert mit einem relativen Pfad
        ///     Den Refresh im try-catch braucht es oft bei MyWorld, da der Webdriver dort oft hängen bleibt
        /// </summary>
        /// <param name="driver">Selenium Webdriver</param>
        /// <param name="path">Pfad relativ zur Adresse</param>
        public static void NavigateToPath(this IWebDriver driver, string path)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
            Uri myUri = new Uri(driver.Url);
            string baseURL = myUri.GetLeftPart(UriPartial.Authority);
            string newURL = (baseURL + path).ToString();
            try
            {
                driver.Url = newURL;
            }
            catch (Exception)
            {
                driver.Navigate().Refresh();
            }

        }

        /// <summary>
        ///     Navigiert mit einem relativen Pfad und wartet, bis das gesuchte Element sichtbar ist und gibt dieses dann zurück.
        ///     Den Refresh im try-catch braucht es oft bei MyWorld, da der Webdriver dort oft hängen bleibt
        /// </summary>
        /// <param name="driver">Selenium Webdriver</param>
        /// <param name="path">Pfad relativ zur Adresse</param>
        /// <param name="by">Selenium By</param>
        public static IWebElement NavigateToPath(this IWebDriver driver, string path, By by)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
            Uri myUri = new Uri(driver.Url);
            string baseURL = myUri.GetLeftPart(UriPartial.Authority);
            string newURL = (baseURL + path).ToString();
            try
            {
                driver.Url = newURL;
            }
            catch (Exception)
            {
                driver.Navigate().Refresh();
            }
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            IWebElement result = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(by));
            return result;
        }
        #endregion

        #region LocalStorage Helpers
        /// <summary>
        ///     Schreibt einen Wert in den Local Storage des aktuellen WebDriver
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public static void LocalStorageSetItem(this IWebDriver driver, string key, string value)
        {
            IJavaScriptExecutor ScriptExecutor = (IJavaScriptExecutor)driver;
            ScriptExecutor.ExecuteScript(string.Format("window.localStorage.setItem('{0}','{1}');", key, value));
        }

        /// <summary>
        ///     Liest dern Wert von "key" aus dem LocalStorage
        /// </summary>
        /// <param name="key"></param>
        /// <returns>(string) Value</returns>
        public static string LocalStorageGetItem(this IWebDriver driver, string key)
        {
            IJavaScriptExecutor ScriptExecutor = (IJavaScriptExecutor)driver;
            return (string)ScriptExecutor.ExecuteScript(string.Format("return window.localStorage.getItem('{0}');", key));
        }

        /// <summary>
        ///     Löscht alle Einträge aus dem Local Storage
        /// </summary>
        public static void LocalStorageClear(this IWebDriver driver)
        {
            IJavaScriptExecutor ScriptExecutor = (IJavaScriptExecutor)driver;
            ScriptExecutor.ExecuteScript("window.localStorage.clear();");
        }

        /// <summary>
        ///     Gibt die Anzahl Einträge im Local Storage zurück
        /// </summary>
        /// <returns>(int) Count of Elements</returns>
        public static int LocalStorageLength(this IWebDriver driver)
        {
            IJavaScriptExecutor ScriptExecutor = (IJavaScriptExecutor)driver;
            return (int)ScriptExecutor.ExecuteScript("return window.localStorage.length;");
        }
        #endregion

        #region IsElementPresent
        /// <summary>
        ///     Prüft, ob ein Element vorhanden ist
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <returns></returns>
        public static bool IsElementPresent(this IWebDriver driver, By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        /// <summary>
        ///     Prüft, ob ein Element innerhalb eines Elements vorhanden ist
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <returns></returns>
        public static bool IsElementPresent(this IWebDriver driver, dynamic element, By by)
        {
            try
            {
                element.FindElement(by);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        #endregion

        #region GetElementSafe
        /// <summary>
        ///     Rückgabe des Elements in einem Try Catch Block, damit kein Fehler auftritt
        /// </summary>
        /// <param name="by"></param>
        /// <returns>IWebElement</returns>
        public static IWebElement GetElementSafe(this IWebDriver driver, By by)
        {
            IWebElement result;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            try
            {
                result = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(by));
                result = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(by));
            }
            catch (NoSuchElementException e)
            {
                return null;
            }
            return result;
        }

        /// <summary>
        ///     Returns the expected Selenium WebElement when it's really is usable
        /// </summary>
        /// <param name="by">Selenium By</param>
        /// <param name="shouldHidden">Selenium By Element that should no longer to be visible.</param>
        /// <param name="MillisecondsToWait">Integer / Default 1000</param>
        /// <returns>Selenium WebElement</returns>
        public static IWebElement GetElementSafe(this IWebDriver driver, By by, By shouldHidden, int MillisecondsToWait = 1000)
        {
            IWebElement result;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            try
            {
                result = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(by));
                result = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(by));
                Thread.Sleep(MillisecondsToWait);
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(shouldHidden));
            }
            catch (Exception e)
            {
                return null;
            }
            return result;
        }
        #endregion

        #region Sonstige Hilfsmethoden
        /// <summary>
        ///     Setzt die Browsergrösse auf die entsprechende Grösse
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public static void SetMobileSize(this IWebDriver driver, int width = 750, int height = 1024)
        {
            driver.Manage().Window.Size = new Size(width, height);
        }

        /// <summary>
        ///     Hilfsmethode, um Screenshots kategorisiert abzulegen
        /// </summary>
        /// <param name="fileName"></param>
        public static void MakeScreenshot(this IWebDriver driver, string fileName)
        {
            var version = System.Environment.GetEnvironmentVariable("Version");

            if (string.IsNullOrEmpty(version))
            {
                version = "1.0.0";
            }

            var artifactDirectory = Path.Combine(Directory.GetCurrentDirectory(), @"..\");
            artifactDirectory = Path.GetFullPath(Path.Combine(artifactDirectory, $"SeleniumResults\\{version}"));
            if (!Directory.Exists(artifactDirectory))
            {
                Directory.CreateDirectory(artifactDirectory);
            }

            var screenshotFilePath = Path.Combine(artifactDirectory, fileName);

            try
            {
                Screenshot screenshot = ((ITakesScreenshot)driver).GetScreenshot();
                screenshot.SaveAsFile(screenshotFilePath, ScreenshotImageFormat.Png);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }

        }

        /// <summary>
        ///     JavaScript ausführen über den WebDriver
        /// </summary>
        /// <param name="script"></param>
        public static void ExecuteScript(this IWebDriver driver, string script)
        {
            IJavaScriptExecutor ScriptExecutor = (IJavaScriptExecutor)driver;
            ScriptExecutor.ExecuteScript(script);
        }
        #endregion
    }
}
