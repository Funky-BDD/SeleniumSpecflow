﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;

namespace $safeprojectname$
{
    [Binding]
    public sealed class Hooks
    {
        public static IWebDriver Driver;
        public static WebDriverWait Wait;
        private static string _screenShotFileName;
        private static string _browserName;


        private void _initDriver(string browser)
        {
            _browserName = browser;
            switch (browser)
            {
                case "Edge":
                    Driver = new EdgeDriver("./");
                    break;
                case "IE":
                    Driver = new InternetExplorerDriver("./");
                    break;
                case "Firefox":
                    Driver = new FirefoxDriver("./");
                    break;
                default:
                    Driver = new ChromeDriver("./");
                    break;
            }
            Driver.Manage().Window.Maximize();
            Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
        }

        [BeforeScenario(Order = 1)]
        public void BeforeScenario()
        {
            _screenShotFileName = $"{FeatureContext.Current.FeatureInfo.Title}__{ScenarioContext.Current.ScenarioInfo.Title}.png";
        }

        [BeforeScenario(Order = 2)]
        [Scope(Tag = "Chrome")]
        public void OpenChrome()
        {
            _initDriver("Chrome");
        }

        [BeforeScenario(Order = 2)]
        [Scope(Tag = "Firefox")]
        public void OpenFirefox()
        {
            _initDriver("Firefox");
        }

        [BeforeScenario(Order = 2)]
        [Scope(Tag = "Edge")]
        public void OpenEdge()
        {
            _initDriver("Edge");
        }

        [BeforeScenario(Order = 2)]
        [Scope(Tag = "IE")]
        public void OpenIE()
        {
            _initDriver("IE");
        }

        [AfterScenario]
        public void AfterScenario()
        {
            string TimeStamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss-fff");
            string State = (ScenarioContext.Current.TestError != null ? "ERROR" : "OK");
            string FileName = $"{TimeStamp}___{_browserName}___{State}___{_screenShotFileName}";
            Driver.MakeScreenshot(FileName);
            Driver.Close();
            Driver.Quit();
        }

    }
}
